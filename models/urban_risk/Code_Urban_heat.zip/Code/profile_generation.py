import pandas as pd
import numpy as np

# Example: Generate 10,000 resident profiles
num_agents = 10000

# Age distribution
ages = np.random.choice(
    [15, 40, 70],  # Representative ages for young, adult, elderly
    size=num_agents,
    p=[0.3, 0.5, 0.2]  # Probabilities based on census
)

# Health status (0: low risk, 1: high risk)
health_status = np.random.choice(
    [0, 1],
    size=num_agents,
    p=[0.9, 0.1]  # 10% high risk
)

# Mobility (walking speed in m/s)
mobility = np.where(ages > 65, np.random.normal(1, 0.2), np.random.normal(1.5, 0.3))

# Heat sensitivity (0 to 1)
heat_sensitivity = np.where(health_status == 1, np.random.uniform(0.7, 1), np.random.uniform(0, 0.7))

# Shelter awareness (0 or 1)
shelter_awareness = np.random.choice([0, 1], size=num_agents, p=[0.2, 0.8])

# Create DataFrame
residents = pd.DataFrame({
    'agent_id': range(num_agents),
    'age': ages,
    'health_status': health_status,
    'mobility': mobility,
    'heat_sensitivity': heat_sensitivity,
    'shelter_awareness': shelter_awareness
})

# Save to CSV
residents.to_csv('residents.csv', index=False)