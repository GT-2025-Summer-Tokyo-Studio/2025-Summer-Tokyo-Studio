import os
import logging
import pandas as pd
import numpy as np
import osmnx as ox
import networkx as nx
import geopandas as gpd
import requests
from shapely.geometry import Point, LineString, Polygon
from colorama import init, Fore, Style
from tqdm import tqdm
import matplotlib.pyplot as plt

# Initialize colorama for colored output
init()

# Hardcoded API key
GOOGLE_MAPS_API_KEY = "AIzaSyAlXyyMyJ2JdHCGslCw_1dFxIzDw5KaIIQ"

# Constants
DRIVING_SPEED_KMH = 30  # Driving speed in km/h
BASE_WALKING_SPEED_MPS = 1.4  # Base walking speed in meters per second (approx 5 km/h)
WATER_PER_MINUTE = 0.008  # Liters of water needed per minute of walking

# Vulnerability factors
VULNERABILITY_FACTORS = {'Low': 1.0, 'Medium': 1.5, 'High': 2.0}
LEVEL_ORDER = {'Low': 1, 'Medium': 2, 'High': 3}

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def test_api_key(api_key):
    """Test the Google Maps API key with a sample geocoding request."""
    test_address = "Tokyo, Japan"
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={test_address}&region=jp&key={api_key}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data['status'] == 'OK':
            logging.info("Google Maps API key is valid.")
            print(f"{Fore.GREEN}Google Maps API key is valid.{Style.RESET_ALL}")
            return True
        else:
            logging.error(f"Google Maps API key test failed: {data['status']}")
            print(f"{Fore.RED}Google Maps API key test failed: {data['status']}. Please verify your API key.{Style.RESET_ALL}")
            return False
    except requests.RequestException as e:
        logging.error(f"Google Maps API key test failed: {e}")
        print(f"{Fore.RED}Google Maps API key test failed: {e}. Please verify your API key.{Style.RESET_ALL}")
        return False

def load_walking_graph(polygon):
    """Load walking graph from polygon."""
    logging.info("Loading walking graph from polygon...")
    return ox.graph_from_polygon(polygon, network_type='walk')

def load_driving_graph(polygon):
    """Load driving graph from polygon."""
    logging.info("Loading driving graph from polygon...")
    return ox.graph_from_polygon(polygon, network_type='drive')

def geocode_address(address, api_key):
    """Geocode an address using Google Maps API with Nominatim fallback."""
    # Try Google Maps API first
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={address}&region=jp&key={api_key}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data['status'] == 'OK':
            location = data['results'][0]['geometry']['location']
            logging.info(f"Geocoded {address} to {location['lat']}, {location['lng']} via Google Maps")
            return location['lat'], location['lng']
        else:
            logging.warning(f"Google Maps geocoding failed: {data['status']}")
    except requests.RequestException as e:
        logging.error(f"Google Maps API request failed: {e}")

    # Fallback to Nominatim
    try:
        url = f"https://nominatim.openstreetmap.org/search?q={address}&format=json&limit=1"
        headers = {'User-Agent': 'NihonbashiRoutePlanner/1.0'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data:
            lat, lon = float(data[0]['lat']), float(data[0]['lon'])
            logging.info(f"Geocoded {address} to {lat}, {lon} via Nominatim")
            return lat, lon
        else:
            logging.error("Nominatim geocoding returned no results")
            return None
    except requests.RequestException as e:
        logging.error(f"Nominatim API request failed: {e}")
        return None

def load_nihonbashi_boundary():
    """Load Nihonbashi boundary shapefile and convert to polygon in EPSG:4326."""
    logging.info("Loading Nihonbashi boundary shapefile...")
    try:
        boundary = gpd.read_file("Nihonbashi_Line.shp")
        if boundary.crs is None:
            boundary.set_crs(epsg=2451, inplace=True)  # Assume Tokyo UTM Zone 54N if unspecified
        boundary = boundary.to_crs(epsg=4326)  # Convert to WGS84

        geom = boundary.geometry.iloc[0]
        if geom.type == 'Polygon':
            polygon = geom
        elif geom.type == 'LineString':
            if not geom.is_ring:
                coords = list(geom.coords)
                if coords[0] != coords[-1]:
                    coords.append(coords[0])
                geom = LineString(coords)
            polygon = Polygon(geom)
        else:
            raise ValueError("Unsupported geometry type")
        if not polygon.is_valid:
            polygon = polygon.buffer(0)  # Fix invalid polygon
        boundary.at[boundary.index[0], 'geometry'] = polygon
        return boundary
    except Exception as e:
        logging.error(f"Failed to load boundary shapefile: {e}")
        raise

def load_evacuation_shelters():
    """Load evacuation shelters from provided CSV data."""
    logging.info("Loading evacuation shelters from CSV...")
    try:
        shelters_data = pd.read_csv("evac_shelters.csv")
        shelters_data['geometry'] = shelters_data.apply(lambda row: Point(row['longitude'], row['latitude']), axis=1)
        return gpd.GeoDataFrame(shelters_data, geometry='geometry', crs="EPSG:4326")
    except Exception as e:
        logging.error(f"Failed to load shelters CSV: {e}")
        raise

def calculate_path_stats(G, path, speed_mps):
    """Calculate statistics for a given path."""
    try:
        distance = nx.path_weight(G, path, weight='length')
        time = distance / speed_mps / 60  # Minutes
        water_needed = time * WATER_PER_MINUTE
        return {
            'distance_m': distance,
            'time_min': time,
            'water_needed_l': water_needed
        }
    except Exception as e:
        logging.error(f"Failed to calculate path stats: {e}")
        return None

def main():
    """Main function to run the route planner."""
    print(f"{Fore.CYAN}=== Nihonbashi Evacuation Route Planner v4 ==={Style.RESET_ALL}")
    
    # Test Google Maps API key
    if not test_api_key(GOOGLE_MAPS_API_KEY):
        print(f"{Fore.RED}Please fix your Google Maps API key before proceeding. Exiting.{Style.RESET_ALL}")
        return
    
    # Load boundary and get polygon
    try:
        boundary = load_nihonbashi_boundary()
        polygon = boundary.geometry.iloc[0]
    except Exception as e:
        print(f"{Fore.RED}Failed to load boundary: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Load graphs from polygon
    try:
        walking_graph = load_walking_graph(polygon)
        driving_graph = load_driving_graph(polygon)
    except Exception as e:
        print(f"{Fore.RED}Failed to load graphs: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Load shelters and filter those within the boundary
    try:
        shelters = load_evacuation_shelters()
        shelters = shelters[shelters.geometry.within(polygon)]
        if shelters.empty:
            print(f"{Fore.RED}No shelters found within the boundary. Exiting.{Style.RESET_ALL}")
            return
    except Exception as e:
        print(f"{Fore.RED}Failed to load shelters: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Get starting point
    while True:
        start_address = input("Enter your starting address in Nihonbashi (e.g., '19-21 Nihonbashihakozakicho, Chuo City, Tokyo 103-8510, Japan'): ")
        start_coords = geocode_address(start_address, GOOGLE_MAPS_API_KEY)
        if start_coords:
            start_point = Point(start_coords[1], start_coords[0])
            if polygon.contains(start_point):
                print(f"{Fore.GREEN}Address is within Nihonbashi boundary.{Style.RESET_ALL}")
                break
            else:
                print(f"{Fore.RED}Address is outside Nihonbashi boundary. Please try again.{Style.RESET_ALL}")
                logging.warning(f"Point {start_coords} not within boundary")
        else:
            print(f"{Fore.RED}Geocoding failed. Please try again or verify your Google Maps API key.{Style.RESET_ALL}")
    
    # Calculate distances to shelters
    shelters['distance'] = shelters.geometry.apply(lambda x: start_point.distance(x) * 111000)  # Approx meters
    top_shelters = shelters.nsmallest(5, 'distance')
    
    # User selects shelter
    print("\nTop 5 closest shelters:")
    for num, (idx, row) in enumerate(top_shelters.iterrows(), start=1):
        print(f"{num}. {row['Name']} - {row['distance']:.2f} m")
    try:
        choice = int(input("Select a shelter (1-5): "))
        if choice < 1 or choice > 5:
            raise ValueError("Please enter a number between 1 and 5.")
        selected_shelter = top_shelters.iloc[choice - 1]
        goal_coords = (selected_shelter.geometry.y, selected_shelter.geometry.x)
    except ValueError as e:
        print(f"{Fore.RED}Invalid input: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Find nearest nodes
    try:
        start_node = ox.distance.nearest_nodes(walking_graph, start_coords[1], start_coords[0])
        goal_node = ox.distance.nearest_nodes(walking_graph, goal_coords[1], goal_coords[0])
        start_node_drive = ox.distance.nearest_nodes(driving_graph, start_coords[1], start_coords[0])
        goal_node_drive = ox.distance.nearest_nodes(driving_graph, goal_coords[1], goal_coords[0])
        # Check if nodes are in the graph
        if start_node not in walking_graph:
            raise ValueError(f"Start node {start_node} not in walking graph")
        if goal_node not in walking_graph:
            raise ValueError(f"Goal node {goal_node} not in walking graph")
        if start_node_drive not in driving_graph:
            raise ValueError(f"Start node {start_node_drive} not in driving graph")
        if goal_node_drive not in driving_graph:
            raise ValueError(f"Goal node {goal_node_drive} not in driving graph")
    except Exception as e:
        print(f"{Fore.RED}Failed to find nearest nodes: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Calculate paths
    try:
        short_path = nx.shortest_path(walking_graph, start_node, goal_node, weight='length')
        drive_path = nx.shortest_path(driving_graph, start_node_drive, goal_node_drive, weight='length')
    except nx.NetworkXNoPath:
        print(f"{Fore.RED}No path found to the selected shelter.{Style.RESET_ALL}")
        return
    except Exception as e:
        print(f"{Fore.RED}Failed to calculate paths: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Calculate statistics
    short_stats = calculate_path_stats(walking_graph, short_path, BASE_WALKING_SPEED_MPS)
    drive_stats = calculate_path_stats(driving_graph, drive_path, DRIVING_SPEED_KMH * 1000 / 3600)
    
    if short_stats and drive_stats:
        # Display results
        print(f"\n{Fore.GREEN}Shortest Walking Path:{Style.RESET_ALL}")
        for k, v in short_stats.items():
            print(f"{k}: {v:.2f}")
        print(f"\n{Fore.GREEN}Driving Path:{Style.RESET_ALL}")
        for k, v in drive_stats.items():
            print(f"{k}: {v:.2f}")
        
        # Plot routes
        try:
            fig, ax = ox.plot_graph_routes(walking_graph, [short_path], route_colors=['b'], route_linewidths=2, bgcolor='w')
            ox.plot_graph_route(driving_graph, drive_path, route_color='g', route_linewidth=2, ax=ax)
            plt.title("Evacuation Routes to Shelter")
            plt.show()
        except Exception as e:
            print(f"{Fore.RED}Failed to plot routes: {e}.{Style.RESET_ALL}")
    else:
        print(f"{Fore.RED}Failed to calculate path statistics.{Style.RESET_ALL}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        print(f"{Fore.RED}An error occurred. Check logs for details.{Style.RESET_ALL}")

# Note: If you encounter issues with the Google Maps API key, verify it in the Google Cloud Console:
# 1. Go to https://console.cloud.google.com/apis/credentials
# 2. Ensure the Geocoding API is enabled for your project.
# 3. Check if billing is enabled.
# 4. If you have HTTP referrer restrictions, ensure they match your request.
# 5. Test your API key with a simple HTTP request:
#    curl "https://maps.googleapis.com/maps/api/geocode/json?address=Tokyo,Japan&key=your_api_key"
# 6. If issues persist, use the Google Maps Platform API Checker Chrome extension:
#    https://chrome.google.com/webstore/detail/google-maps-platform-api/ggnpifedofnjbhfmldednfehecjklcjd