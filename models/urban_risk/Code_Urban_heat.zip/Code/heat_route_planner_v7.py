import os
import logging
import pandas as pd
import numpy as np
import osmnx as ox
import networkx as nx
import geopandas as gpd
import requests
from shapely.geometry import Point, LineString, Polygon
from colorama import init, Fore, Style
from tqdm import tqdm
import matplotlib
matplotlib.use('Agg')  # Set non-interactive backend to avoid Tkinter issues
import matplotlib.pyplot as plt
import mesa
from mesa import Model, Agent
from mesa.space import NetworkGrid
import random
from collections import defaultdict
import ast
import folium
from matplotlib import colormaps as cmaps
import matplotlib.colors as mcolors
from shapely.ops import polygonize

# Initialize colorama for colored output
init()

# Hardcoded API key
GOOGLE_MAPS_API_KEY = "AIzaSyAlXyyMyJ2JdHCGslCw_1dFxIzDw5KaIIQ"

# Constants
DRIVING_SPEED_KMH = 30  # Driving speed in km/h
BASE_WALKING_SPEED_MPS = 1.4  # Base walking speed in meters per second (approx 5 km/h)
WATER_PER_MINUTE = 0.008  # Liters of water needed per minute of walking

# Vulnerability factors
VULNERABILITY_FACTORS = {'Low': 1.0, 'Medium': 1.5, 'High': 2.0}
LEVEL_ORDER = {'Low': 1, 'Medium': 2, 'High': 3}

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def test_api_key(api_key):
    """Test the Google Maps API key with a sample geocoding request."""
    test_address = "Tokyo, Japan"
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={test_address}®ion=jp&key={api_key}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data['status'] == 'OK':
            logging.info("Google Maps API key is valid.")
            print(f"{Fore.GREEN}Google Maps API key is valid.{Style.RESET_ALL}")
            return True
        else:
            logging.error(f"Google Maps API key test failed: {data['status']}")
            print(f"{Fore.RED}Google Maps API key test failed: {data['status']}. Please verify your API key.{Style.RESET_ALL}")
            return False
    except requests.RequestException as e:
        logging.error(f"Google Maps API key test failed: {e}")
        print(f"{Fore.RED}Google Maps API key test failed: {e}. Please verify your API key.{Style.RESET_ALL}")
        return False

def load_walking_graph(polygon):
    """Load walking graph from polygon."""
    logging.info("Loading walking graph from polygon...")
    return ox.graph_from_polygon(polygon, network_type='walk')

def load_driving_graph(polygon):
    """Load driving graph from polygon."""
    logging.info("Loading driving graph from polygon...")
    return ox.graph_from_polygon(polygon, network_type='drive')

def geocode_address(address, api_key):
    """Geocode an address using Google Maps API with Nominatim fallback."""
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={address}®ion=jp&key={api_key}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data['status'] == 'OK':
            location = data['results'][0]['geometry']['location']
            logging.info(f"Geocoded {address} to {location['lat']}, {location['lng']} via Google Maps")
            return location['lat'], location['lng']
        else:
            logging.warning(f"Google Maps geocoding failed: {data['status']}")
    except requests.RequestException as e:
        logging.error(f"Google Maps API request failed: {e}")

    try:
        url = f"https://nominatim.openstreetmap.org/search?q={address}&format=json&limit=1"
        headers = {'User-Agent': 'NihonbashiRoutePlanner/1.0'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data:
            lat, lon = float(data[0]['lat']), float(data[0]['lon'])
            logging.info(f"Geocoded {address} to {lat}, {lon} via Nominatim")
            return lat, lon
        else:
            logging.error("Nominatim geocoding returned no results")
            return None
    except requests.RequestException as e:
        logging.error(f"Nominatim API request failed: {e}")
        return None

def load_nihonbashi_boundary():
    """Load Nihonbashi boundary shapefile and convert to polygon in EPSG:4326."""
    logging.info("Loading Nihonbashi boundary shapefile...")
    try:
        boundary = gpd.read_file("Nihonbashi_Line.shp")
        if boundary.crs is None:
            boundary.set_crs(epsg=2451, inplace=True)
        boundary = boundary.to_crs(epsg=4326)
        geom = boundary.geometry.iloc[0]
        if geom.geom_type == 'Polygon':
            polygon = geom
        elif geom.geom_type == 'LineString':
            if not geom.is_ring:
                coords = list(geom.coords)
                if coords[0] != coords[-1]:
                    coords.append(coords[0])
                geom = LineString(coords)
            polygon = Polygon(geom)
        else:
            raise ValueError("Unsupported geometry type")
        if not polygon.is_valid:
            polygon = polygon.buffer(0)
        boundary.at[boundary.index[0], 'geometry'] = polygon
        return boundary
    except Exception as e:
        logging.error(f"Failed to load boundary shapefile: {e}")
        raise

def load_evacuation_shelters():
    """Load evacuation shelters from provided CSV data."""
    logging.info("Loading evacuation shelters from CSV...")
    try:
        shelters_data = pd.read_csv("evac_shelters.csv")
        shelters_data['geometry'] = shelters_data.apply(lambda row: Point(row['longitude'], row['latitude']), axis=1)
        return gpd.GeoDataFrame(shelters_data, geometry='geometry', crs="EPSG:4326")
    except Exception as e:
        logging.error(f"Failed to load shelters CSV: {e}")
        raise

class EvacueeAgent(Agent):
    """Agent representing an evacuee moving to a shelter."""
    def __init__(self, model, start_node, destination_node, vulnerability):
        super().__init__(model)
        self.start_node = start_node
        self.current_node = start_node
        self.destination_node = destination_node
        self.vulnerability = vulnerability
        self.speed = BASE_WALKING_SPEED_MPS / VULNERABILITY_FACTORS[vulnerability]
        self.arrival_time = None
        try:
            self.path = nx.shortest_path(model.walking_graph, start_node, destination_node, weight='length')
            if len(self.path) > 1:
                self.position_index = 0
                self.current_edge_remaining = model.walking_graph[self.path[0]][self.path[1]][0]['length']
                self.arrived = False
            else:
                self.position_index = len(self.path) - 1
                self.arrived = True
                self.arrival_time = 0
                self.current_edge_remaining = 0
            self.total_distance = sum(model.walking_graph[u][v][0]['length'] for u, v in zip(self.path[:-1], self.path[1:])) if self.path else 0
        except nx.NetworkXNoPath:
            print(f"{Fore.RED}No path for agent {self.unique_id}{Style.RESET_ALL}")
            self.path = []
            self.total_distance = 0
            self.arrived = True
            self.arrival_time = 0
            self.current_edge_remaining = 0

    def step(self):
        if self.arrived:
            return
        distance_to_cover = self.speed * 60  # meters per minute
        while distance_to_cover > 0 and self.position_index < len(self.path) - 1:
            if self.current_edge_remaining <= distance_to_cover:
                distance_to_cover -= self.current_edge_remaining
                self.position_index += 1
                if self.position_index < len(self.path) - 1:
                    self.current_edge_remaining = self.model.walking_graph[self.path[self.position_index]][self.path[self.position_index + 1]][0]['length']
                else:
                    self.current_edge_remaining = 0
                next_node = self.path[self.position_index]
                self.model.grid.move_agent(self, next_node)
                self.current_node = next_node
                if self.position_index == len(self.path) - 1:
                    self.arrived = True
                    self.arrival_time = self.model.time
                    break
            else:
                self.current_edge_remaining -= distance_to_cover
                distance_to_cover = 0

class EvacuationModel(Model):
    """Model for simulating evacuation of multiple agents to a chosen shelter."""
    def __init__(self, num_agents, walking_graph, shelters, start_node, shelter_nodes):
        super().__init__()
        self.num_agents = num_agents
        self.walking_graph = walking_graph
        self.shelters = shelters
        self.grid = NetworkGrid(walking_graph)
        self.time = 0
        self.evacuees = []
        self.shelter_nodes = shelter_nodes

        # Create mapping from shelter nodes to shelter indices
        all_shelter_nodes = [ox.distance.nearest_nodes(walking_graph, s.geometry.x, s.geometry.y) for s in shelters.itertuples()]
        self.shelter_mapping = {node: i for i, node in enumerate(all_shelter_nodes) if node in self.shelter_nodes}

        # Create agents
        for i in range(num_agents):
            vulnerability = random.choice(['Low', 'Medium', 'High'])
            destination_node = random.choice(self.shelter_nodes)
            agent = EvacueeAgent(self, start_node, destination_node, vulnerability)
            self.evacuees.append(agent)
            self.grid.place_agent(agent, start_node)
        self.running = True

    def step(self):
        random.shuffle(self.evacuees)
        for agent in self.evacuees:
            agent.step()
        self.time += 1
        if all(agent.arrived for agent in self.evacuees):
            self.running = False

def main():
    """Main function to run the ABM evacuation route planner."""
    print(f"{Fore.CYAN}=== Nihonbashi Evacuation Route Planner v10 (ABM) ==={Style.RESET_ALL}")
    
    # Test Google Maps API key
    if not test_api_key(GOOGLE_MAPS_API_KEY):
        print(f"{Fore.RED}Please fix your Google Maps API key before proceeding. Exiting.{Style.RESET_ALL}")
        return
    
    # Load boundary and get polygon
    try:
        boundary = load_nihonbashi_boundary()
        polygon = boundary.geometry.iloc[0]
    except Exception as e:
        print(f"{Fore.RED}Failed to load boundary: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Load walking graph
    try:
        walking_graph = load_walking_graph(polygon)
        # Log maximum edge length for debugging
        max_edge_length = max((data['length'] for u, v, data in walking_graph.edges(data=True)), default=0)
        logging.info(f"Maximum edge length in walking graph: {max_edge_length} meters")
    except Exception as e:
        print(f"{Fore.RED}Failed to load walking graph: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Load shelters and filter those within the boundary
    try:
        shelters = load_evacuation_shelters()
        shelters = shelters[shelters.geometry.within(polygon)]
        if shelters.empty:
            print(f"{Fore.RED}No shelters found within the boundary. Exiting.{Style.RESET_ALL}")
            return
    except Exception as e:
        print(f"{Fore.RED}Failed to load shelters: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Get starting address
    start_address = input("Enter starting address: ")
    start_coords = geocode_address(start_address, GOOGLE_MAPS_API_KEY)
    if start_coords is None:
        print(f"{Fore.RED}Failed to geocode starting address. Exiting.{Style.RESET_ALL}")
        return
    start_lat, start_lon = start_coords
    
    # Find nearest node to start
    try:
        start_node = ox.distance.nearest_nodes(walking_graph, start_lon, start_lat)
    except Exception as e:
        print(f"{Fore.RED}Failed to find nearest node for start address: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Compute shelter nodes
    shelter_nodes = [ox.distance.nearest_nodes(walking_graph, s.geometry.x, s.geometry.y) for s in shelters.itertuples()]
    shelter_mapping = {node: i for i, node in enumerate(shelter_nodes)}
    
    # Compute distances to shelters
    try:
        lengths = nx.single_source_dijkstra_path_length(walking_graph, start_node, weight='length')
        shelter_distances = {shelter_node: lengths[shelter_node] for shelter_node in shelter_nodes if shelter_node in lengths}
        if not shelter_distances:
            print(f"{Fore.RED}No shelters reachable from the starting location. Exiting.{Style.RESET_ALL}")
            return
        top_5_shelters = sorted(shelter_distances.items(), key=lambda x: x[1])[:5]
    except Exception as e:
        print(f"{Fore.RED}Failed to compute shelter distances: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Display top 5 shelters
    print(f"{Fore.CYAN}Closest evacuation shelters:{Style.RESET_ALL}")
    shelter_options = []
    for i, (shelter_node, distance) in enumerate(top_5_shelters, 1):
        shelter_idx = shelter_mapping[shelter_node]
        shelter_info = shelters.iloc[shelter_idx]
        name = shelter_info.get('name', f"Shelter at {shelter_info['latitude']:.4f}, {shelter_info['longitude']:.4f}")
        print(f"{i}. {name} - Distance: {distance:.2f} meters")
        shelter_options.append(shelter_node)
    print("Agents will be assigned randomly to these shelters.")
    
    # Get number of agents
    while True:
        try:
            num_agents = int(input("Enter number of agents to simulate: "))
            if num_agents <= 0:
                raise ValueError("Number of agents must be positive.")
            break
        except ValueError as e:
            print(f"{Fore.RED}Invalid input: {e}. Please enter a positive integer.{Style.RESET_ALL}")
    
    # Run ABM simulation
    try:
        model = EvacuationModel(num_agents, walking_graph, shelters, start_node, shelter_options)
        with tqdm(total=None, desc="Simulating evacuation") as pbar:
            while model.running:
                model.step()
                pbar.update(1)
        
        # Collect and analyze data
        data = []
        for agent in model.evacuees:
            if agent.arrival_time is not None:
                water_needed = agent.arrival_time * WATER_PER_MINUTE
                data.append({
                    'vulnerability': agent.vulnerability,
                    'arrival_time': agent.arrival_time,
                    'distance': agent.total_distance,
                    'water_needed': water_needed,
                    'start_node': agent.start_node,
                    'destination_node': agent.destination_node,
                    'path': agent.path
                })
        
        if not data:
            print(f"{Fore.RED}No agents reached the shelter. Check graph connectivity or shelter location.{Style.RESET_ALL}")
            return
        
        df = pd.DataFrame(data)
        print(f"\n{Fore.GREEN}Simulation completed.{Style.RESET_ALL}")
        print(f"Average arrival time: {df['arrival_time'].mean():.2f} minutes")
        print(f"Total water needed: {df['water_needed'].sum():.2f} liters")
        print(f"Average distance traveled: {df['distance'].mean():.2f} meters")
        print(f"\n{Fore.GREEN}Statistics by vulnerability:{Style.RESET_ALL}")
        stats = df.groupby('vulnerability').agg({
            'arrival_time': ['mean', 'count'],
            'distance': 'mean',
            'water_needed': 'sum'
        }).round(2)
        print(stats)
        df.to_csv('evacuation_data.csv', index=False)
        print(f"\n{Fore.GREEN}Data saved to 'evacuation_data.csv'.{Style.RESET_ALL}")
        
        # Visualization part starts here
        # Get nodes GeoDataFrame
        nodes = ox.graph_to_gdfs(walking_graph, nodes=True)[0]
        
        # Group by destination_node
        grouped = df.groupby('destination_node')
        
        # Get unique destinations and assign colors using a colormap
        unique_dests = sorted(df['destination_node'].unique())
        num_dests = len(unique_dests)
        cmap = cmaps['tab10']
        colors = [cmap(i) for i in np.linspace(0, 1, num_dests)]
        dest_color = dict(zip(unique_dests, colors))
        shelter_nums = {dest: i+1 for i, dest in enumerate(unique_dests)}
        
        # Get unique paths per destination
        unique_paths = df[['destination_node', 'path']].drop_duplicates('destination_node')
        
        # Create the folium map
        start_lat = nodes.loc[start_node]['y']
        start_lon = nodes.loc[start_node]['x']
        folium_map = folium.Map(location=[start_lat, start_lon], zoom_start=15, tiles='openstreetmap')
        
        # Add walking graph edges manually
        for u, v, key, data in walking_graph.edges(keys=True, data=True):
            if 'geometry' in data:
                line = data['geometry']
            else:
                line = LineString([(nodes.loc[u, 'x'], nodes.loc[u, 'y']), (nodes.loc[v, 'x'], nodes.loc[v, 'y'])])
            locations = [(y, x) for x, y in line.coords]
            folium.PolyLine(locations, color='gray', weight=1, opacity=0.5).add_to(folium_map)
        
        # Add boundary
        folium.GeoJson(boundary, style_function=lambda x: {'color': 'black', 'weight': 2, 'fillOpacity': 0}).add_to(folium_map)
        
        # Add paths with statistical tooltips
        for _, row in unique_paths.iterrows():
            path = row['path']
            if len(path) < 2:
                continue
            path_coords = [[nodes.loc[n]['y'], nodes.loc[n]['x']] for n in path if n in nodes.index]  # [lat, lon]
            if path_coords:
                dest = row['destination_node']
                color = dest_color[dest]
                color_hex = mcolors.to_hex(color)
                # Get group data
                group = grouped.get_group(dest)
                distance = group['distance'].iloc[0]
                total_agents = len(group)
                overall_avg_arrival = group['arrival_time'].mean()
                overall_total_water = group['water_needed'].sum()
                vuln_stats = group.groupby('vulnerability').agg({
                    'arrival_time': 'mean',
                    'water_needed': 'mean',
                    'vulnerability': 'count'
                }).rename(columns={'vulnerability': 'count'})
                vuln_stats['percentage'] = vuln_stats['count'] / vuln_stats['count'].sum() * 100
                vuln_stats = vuln_stats.round(2)
                stats_table_html = vuln_stats.to_html(border=1)
                tooltip_html = f"""
                <b>Path to Shelter {shelter_nums[dest]}</b><br>
                Distance: {distance:.2f} meters<br>
                Total Agents: {total_agents}<br>
                Overall Avg Arrival Time: {overall_avg_arrival:.2f} min<br>
                Overall Total Water Needed: {overall_total_water:.2f} L<br>
                <br><b>Statistics by Vulnerability:</b><br>
                {stats_table_html}
                """
                folium.PolyLine(path_coords, color=color_hex, weight=3, opacity=1, tooltip=tooltip_html).add_to(folium_map)
        
        # Add start point
        folium.Marker(location=[start_lat, start_lon], popup='Start Point', icon=folium.Icon(color='red', icon='info-sign')).add_to(folium_map)
        
        # Add shelter points
        for dest in unique_dests:
            if dest in nodes.index:
                lat = nodes.loc[dest]['y']
                lon = nodes.loc[dest]['x']
                folium.Marker(location=[lat, lon], popup=f'Shelter {shelter_nums[dest]}', icon=folium.Icon(color='blue', icon='info-sign')).add_to(folium_map)
        
        # Save the map to HTML
        folium_map.save('evac_paths_enhanced.html')
        print(f"{Fore.GREEN}Map saved to 'evac_paths_enhanced.html'{Style.RESET_ALL}")
    
    except Exception as e:
        print(f"{Fore.RED}Simulation failed: {e}. Exiting.{Style.RESET_ALL}")
        logging.error(f"Simulation error: {e}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        print(f"{Fore.RED}An error occurred. Check logs for details.{Style.RESET_ALL}")