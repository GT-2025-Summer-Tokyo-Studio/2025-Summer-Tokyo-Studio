import os
import logging
import pandas as pd
import numpy as np
import osmnx as ox
import networkx as nx
import geopandas as gpd
import requests
from shapely.geometry import Point, LineString, Polygon
from colorama import init, Fore, Style
from tqdm import tqdm
import matplotlib
matplotlib.use('Agg')  # Set non-interactive backend to avoid Tkinter issues
import matplotlib.pyplot as plt
import mesa
from mesa import Model, Agent
from mesa.space import NetworkGrid
import random
from collections import defaultdict
import ast
import folium
from folium import FeatureGroup, LayerControl
from matplotlib import colormaps as cmaps
import matplotlib.colors as mcolors
from shapely.ops import polygonize

# Initialize colorama for colored output
init()

# Hardcoded API key (as per provided document)
GOOGLE_MAPS_API_KEY = "AIzaSyAlXyyMyJ2JdHCGslCw_1dFxIzDw5KaIIQ"

# Constants
DRIVING_SPEED_KMH = 30  # Driving speed in km/h
BASE_WALKING_SPEED_MPS = 1.4  # Base walking speed in meters per second (approx 5 km/h)
WATER_PER_MINUTE = 0.008  # Liters of water needed per minute of walking

# Vulnerability and mobility factors
VULNERABILITY_FACTORS = {'Low': 1.0, 'Medium': 1.5, 'High': 2.0}
LEVEL_ORDER = {'Low': 1, 'Medium': 2, 'High': 3}
MOBILITY_FACTORS = {'High': 1.0, 'Medium': 0.8, 'Low': 0.6}

# Agent profiles
AGENT_PROFILES = {
    'Elderly': {
        'age': lambda: random.randint(65, 80),
        'vulnerability': lambda: np.random.choice(['Medium', 'High'], p=[0.5, 0.5]),
        'medical_needs': lambda: random.random() < 0.7,
        'family_status': lambda: random.random() < 0.2,
        'mobility_level': lambda: np.random.choice(['Medium', 'Low'], p=[0.5, 0.5]),
        'risk_aversion': lambda: random.uniform(0.7, 1.0),
        'water_reserve': lambda: random.uniform(0.5, 1.0),
        'preferences': {
            'weight_distance': 0.35,
            'weight_heat_avoidance': 0.30,
            'weight_mobility': 0.20,
            'weight_medical': 0.15,
            'weight_capacity': 0.0,
            'weight_group': 0.0
        }
    },
    'Family': {
        'age': lambda: random.randint(30, 50),
        'vulnerability': lambda: np.random.choice(['Low', 'Medium'], p=[0.6, 0.4]),
        'medical_needs': lambda: random.random() < 0.2,
        'family_status': lambda: True,
        'mobility_level': lambda: np.random.choice(['Medium', 'High'], p=[0.7, 0.3]),
        'risk_aversion': lambda: random.uniform(0.5, 0.8),
        'water_reserve': lambda: random.uniform(1.0, 2.0),
        'preferences': {
            'weight_distance': 0.20,
            'weight_heat_avoidance': 0.20,
            'weight_mobility': 0.15,
            'weight_medical': 0.05,
            'weight_capacity': 0.15,
            'weight_group': 0.25
        }
    },
    'Young Adult': {
        'age': lambda: random.randint(18, 35),
        'vulnerability': lambda: np.random.choice(['Low', 'Medium'], p=[0.8, 0.2]),
        'medical_needs': lambda: random.random() < 0.1,
        'family_status': lambda: random.random() < 0.1,
        'mobility_level': lambda: np.random.choice(['High', 'Medium'], p=[0.8, 0.2]),
        'risk_aversion': lambda: random.uniform(0.0, 0.5),
        'water_reserve': lambda: random.uniform(1.0, 2.0),
        'preferences': {
            'weight_distance': 0.30,
            'weight_heat_avoidance': 0.15,
            'weight_mobility': 0.05,
            'weight_medical': 0.0,
            'weight_capacity': 0.30,
            'weight_group': 0.20
        }
    },
    'Mobility Impaired': {
        'age': lambda: random.randint(40, 70),
        'vulnerability': lambda: np.random.choice(['Medium', 'High'], p=[0.5, 0.5]),
        'medical_needs': lambda: random.random() < 0.6,
        'family_status': lambda: random.random() < 0.3,
        'mobility_level': lambda: 'Low',
        'risk_aversion': lambda: random.uniform(0.6, 1.0),
        'water_reserve': lambda: random.uniform(0.5, 1.5),
        'preferences': {
            'weight_distance': 0.25,
            'weight_heat_avoidance': 0.20,
            'weight_mobility': 0.35,
            'weight_medical': 0.15,
            'weight_capacity': 0.05,
            'weight_group': 0.0
        }
    }
}

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def test_api_key(api_key):
    """Test the Google Maps API key with a sample geocoding request."""
    test_address = "Tokyo, Japan"
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={test_address}&region=jp&key={api_key}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data['status'] == 'OK':
            logging.info("Google Maps API key is valid.")
            print(f"{Fore.GREEN}Google Maps API key is valid.{Style.RESET_ALL}")
            return True
        else:
            logging.error(f"Google Maps API key test failed: {data['status']}")
            print(f"{Fore.RED}Google Maps API key test failed: {data['status']}. Please verify your API key.{Style.RESET_ALL}")
            return False
    except requests.RequestException as e:
        logging.error(f"Google Maps API key test failed: {e}")
        print(f"{Fore.RED}Google Maps API key test failed: {e}. Please verify your API key.{Style.RESET_ALL}")
        return False

def load_walking_graph(polygon):
    """Load walking graph from polygon and enhance with attributes."""
    logging.info("Loading walking graph from polygon...")
    graph = ox.graph_from_polygon(polygon, network_type='walk')
    try:
        graph = ox.add_node_elevations_google(graph, api_key=GOOGLE_MAPS_API_KEY)
        graph = ox.add_edge_grades(graph)
    except Exception as e:
        logging.warning(f"Failed to add elevations: {e}. Using synthetic slopes.")
        for u, v, k, data in graph.edges(keys=True, data=True):
            data['grade'] = random.uniform(0, 0.05)
    for u, v, k, data in graph.edges(keys=True, data=True):
        highway = data.get('highway', '')
        data['heat_exposure'] = random.uniform(0.1, 0.4) if highway == 'footway' else random.uniform(0.5, 0.8)
        data['shade_coverage'] = 1 - data['heat_exposure']
        data['rest_areas'] = 1 if random.random() < 0.1 else 0
        data['accessibility_rating'] = 0.2 if 'steps' in str(highway) else random.uniform(0.8, 1.0)
    return graph

def load_driving_graph(polygon):
    """Load driving graph from polygon."""
    logging.info("Loading driving graph from polygon...")
    return ox.graph_from_polygon(polygon, network_type='drive')

def geocode_address(address, api_key):
    """Geocode an address using Google Maps API with Nominatim fallback."""
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?address={address}&region=jp&key={api_key}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data['status'] == 'OK':
            location = data['results'][0]['geometry']['location']
            logging.info(f"Geocoded {address} to {location['lat']}, {location['lng']} via Google Maps")
            return location['lat'], location['lng']
        else:
            logging.warning(f"Google Maps geocoding failed: {data['status']}")
    except requests.RequestException as e:
        logging.error(f"Google Maps API request failed: {e}")

    try:
        url = f"https://nominatim.openstreetmap.org/search?q={address}&format=json&limit=1"
        headers = {'User-Agent': 'NihonbashiRoutePlanner/1.0'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        data = response.json()
        if data:
            lat, lon = float(data[0]['lat']), float(data[0]['lon'])
            logging.info(f"Geocoded {address} to {lat}, {lon} via Nominatim")
            return lat, lon
        else:
            logging.error("Nominatim geocoding returned no results")
            return None
    except requests.RequestException as e:
        logging.error(f"Nominatim API request failed: {e}")
        return None

def load_nihonbashi_boundary():
    """Load Nihonbashi boundary shapefile and convert to polygon in EPSG:4326."""
    if not os.path.exists("Nihonbashi_Line.shp"):
        raise FileNotFoundError("Nihonbashi_Line.shp not found.")
    logging.info("Loading Nihonbashi boundary shapefile...")
    try:
        boundary = gpd.read_file("Nihonbashi_Line.shp")
        if boundary.crs is None:
            boundary.set_crs(epsg=2451, inplace=True)
        boundary = boundary.to_crs(epsg=4326)
        geom = boundary.unary_union
        if geom.geom_type == 'Polygon':
            polygon = geom
        elif geom.geom_type in ['LineString', 'MultiLineString']:
            polygon = polygonize(geom)
            if isinstance(polygon, Polygon):
                pass
            else:
                polygon = next(iter(polygon))
        else:
            raise ValueError("Unsupported geometry type")
        if not polygon.is_valid:
            polygon = polygon.buffer(0)
        boundary.at[boundary.index[0], 'geometry'] = polygon
        return boundary
    except Exception as e:
        logging.error(f"Failed to load boundary shapefile: {e}")
        raise

def load_evacuation_shelters():
    """Load evacuation shelters from provided CSV data."""
    if not os.path.exists("evac_shelters.csv"):
        raise FileNotFoundError("evac_shelters.csv not found.")
    logging.info("Loading evacuation shelters from CSV...")
    try:
        shelters_data = pd.read_csv("evac_shelters.csv")
        shelters_data['geometry'] = shelters_data.apply(lambda row: Point(row['longitude'], row['latitude']), axis=1)
        shelters = gpd.GeoDataFrame(shelters_data, geometry='geometry', crs="EPSG:4326")
        shelters['capacity'] = np.random.randint(50, 201, size=len(shelters))  # Random capacity
        shelters['current_occupancy'] = 0  # Initialize occupancy
        shelters['has_medical'] = np.random.choice([True, False], size=len(shelters))
        shelters['family_friendly'] = np.random.choice([True, False], size=len(shelters))
        shelters['accessible'] = np.random.choice([True, False], size=len(shelters))
        return shelters
    except Exception as e:
        logging.error(f"Failed to load shelters CSV: {e}")
        raise

def calculate_route_attributes(graph, path):
    """Calculate aggregated route attributes from path."""
    if len(path) < 2:
        return {
            'total_length': 0,
            'avg_slope': 0,
            'avg_heat_exposure': 0,
            'avg_shade_coverage': 0,
            'total_rest_areas': 0,
            'avg_accessibility': 0
        }
    total_length = 0
    total_slope = 0
    total_heat = 0
    total_shade = 0
    total_rest = 0
    total_access = 0
    num_edges = len(path) - 1
    for u, v in zip(path[:-1], path[1:]):
        data = graph.get_edge_data(u, v, 0)
        length = data.get('length', 0)
        total_length += length
        total_slope += abs(data.get('grade', 0)) * length
        total_heat += data.get('heat_exposure', 0.5) * length
        total_shade += data.get('shade_coverage', 0.5) * length
        total_rest += data.get('rest_areas', 0)
        total_access += data.get('accessibility_rating', 0.8) * length
    avg_slope = total_slope / total_length if total_length > 0 else 0
    avg_heat = total_heat / total_length if total_length > 0 else 0
    avg_shade = total_shade / total_length if total_length > 0 else 0
    avg_access = total_access / total_length if total_length > 0 else 0
    return {
        'total_length': total_length,
        'avg_slope': avg_slope,
        'avg_heat_exposure': avg_heat,
        'avg_shade_coverage': avg_shade,
        'total_rest_areas': total_rest,
        'avg_accessibility': avg_access
    }

class EvacueeAgent(Agent):
    """Agent representing an evacuee moving to a shelter."""
    def __init__(self, model, start_node, destination_node, profile, vulnerability, age, medical_needs, family_status, mobility_level, risk_aversion, water_reserve, preferences, path, route_attrs):
        super().__init__(model)
        self.start_node = start_node
        self.current_node = start_node
        self.destination_node = destination_node
        self.profile = profile
        self.vulnerability = vulnerability
        self.age = age
        self.medical_needs = medical_needs
        self.family_status = family_status
        self.mobility_level = mobility_level
        self.risk_aversion = risk_aversion
        self.water_reserve = water_reserve
        self.preferences = preferences
        self.speed = (BASE_WALKING_SPEED_MPS / VULNERABILITY_FACTORS[vulnerability]) * MOBILITY_FACTORS[mobility_level]
        self.arrival_time = None
        self.path = path
        self.route_attrs = route_attrs
        self.water_needed = 0.0
        if len(self.path) > 1:
            self.position_index = 0
            self.current_edge_remaining = model.walking_graph[self.path[0]][self.path[1]][0]['length']
            self.arrived = False
        else:
            self.position_index = len(self.path) - 1
            self.arrived = True
            self.arrival_time = 0
            self.current_edge_remaining = 0
        self.total_distance = self.route_attrs['total_length']

    def step(self):
        if self.arrived:
            return
        distance_to_cover = self.speed * 60  # meters per minute
        time_spent = distance_to_cover / self.speed / 60  # minutes
        if self.position_index < len(self.path) - 1:
            edge_data = self.model.walking_graph[self.path[self.position_index]][self.path[self.position_index + 1]][0]
            heat = edge_data.get('heat_exposure', 0.5)
            self.water_needed += WATER_PER_MINUTE * time_spent * (1 + heat)
            self.water_reserve -= WATER_PER_MINUTE * time_spent * (1 + heat)
            if self.water_reserve <= 0:
                self.arrived = True
                return
        while distance_to_cover > 0 and self.position_index < len(self.path) - 1:
            if self.current_edge_remaining <= distance_to_cover:
                distance_to_cover -= self.current_edge_remaining
                self.position_index += 1
                if self.position_index < len(self.path) - 1:
                    self.current_edge_remaining = self.model.walking_graph[self.path[self.position_index]][self.path[self.position_index + 1]][0]['length']
                else:
                    self.current_edge_remaining = 0
                next_node = self.path[self.position_index]
                self.model.grid.move_agent(self, next_node)
                self.current_node = next_node
                if self.position_index == len(self.path) - 1:
                    self.arrived = True
                    self.arrival_time = self.model.time
                    break
            else:
                self.current_edge_remaining -= distance_to_cover
                distance_to_cover = 0

class EvacuationModel(Model):
    """Model for simulating evacuation of multiple agents to a chosen shelter."""
    def __init__(self, num_agents, walking_graph, shelters, start_node, shelter_nodes):
        super().__init__()
        self.num_agents = num_agents
        self.walking_graph = walking_graph
        self.shelters = shelters
        self.grid = NetworkGrid(walking_graph)
        self.time = 0
        self.evacuees = []
        self.shelter_nodes = shelter_nodes
        self.shelter_mapping = {node: i for i, node in enumerate(shelter_nodes)}
        self.max_capacity = self.shelters['capacity'].max()
        self.shelter_occupancy = {node: 0 for node in shelter_nodes}  # Track occupancy

        # Estimate total steps for progress bar
        lengths = nx.single_source_dijkstra_path_length(self.walking_graph, start_node, weight='length')
        avg_distance = np.mean([lengths.get(node, 0) for node in shelter_nodes if node in lengths])
        avg_speed = BASE_WALKING_SPEED_MPS * np.mean(list(MOBILITY_FACTORS.values())) / np.mean(list(VULNERABILITY_FACTORS.values()))
        self.estimated_steps = int((avg_distance / avg_speed / 60) * num_agents * 1.5)  # Conservative estimate

        # Create agents
        profile_choices = list(AGENT_PROFILES.keys())
        for _ in range(num_agents):
            profile = random.choice(profile_choices)
            profile_data = AGENT_PROFILES[profile]
            vulnerability = profile_data['vulnerability']()
            age = profile_data['age']()
            medical_needs = profile_data['medical_needs']()
            family_status = profile_data['family_status']()
            mobility_level = profile_data['mobility_level']()
            risk_aversion = profile_data['risk_aversion']()
            water_reserve = profile_data['water_reserve']()
            preferences = profile_data['preferences'].copy()

            def personal_weight(u, v, d):
                length = d[0].get('length', 0)
                grade = abs(d[0].get('grade', 0))
                heat = d[0].get('heat_exposure', 0.5)
                shade = d[0].get('shade_coverage', 0.5)
                access = d[0].get('accessibility_rating', 0.8)
                cost = length * (1 + preferences['weight_heat_avoidance'] * heat + 
                                preferences['weight_mobility'] * grade - 
                                preferences['weight_heat_avoidance'] * shade - 
                                preferences['weight_mobility'] * access)
                return cost

            utilities = {}
            for shelter_node in self.shelter_nodes:
                shelter_idx = self.shelter_mapping[shelter_node]
                if self.shelter_occupancy[shelter_node] >= self.shelters.iloc[shelter_idx]['capacity']:
                    continue
                try:
                    path = nx.shortest_path(self.walking_graph, start_node, shelter_node, weight=personal_weight)
                    path_cost = nx.shortest_path_length(self.walking_graph, start_node, shelter_node, weight=personal_weight)
                    route_attrs = calculate_route_attributes(self.walking_graph, path)
                except nx.NetworkXNoPath:
                    continue
                shelter = self.shelters.iloc[shelter_idx]
                match_medical = 10 if medical_needs and shelter['has_medical'] else 0
                match_group = 10 if family_status and shelter['family_friendly'] else 0
                match_access = 10 if mobility_level == 'Low' and shelter['accessible'] else 0
                norm_capacity = shelter['capacity'] / self.max_capacity
                utility = (-path_cost * preferences['weight_distance'] + 
                          match_medical * preferences['weight_medical'] + 
                          match_group * preferences['weight_group'] + 
                          match_access * preferences['weight_mobility'] + 
                          norm_capacity * preferences['weight_capacity'])
                utilities[shelter_node] = (utility, path, route_attrs)
            if not utilities:
                logging.warning(f"No reachable shelters with capacity for agent with profile {profile}")
                continue
            sorted_utilities = sorted(utilities.items(), key=lambda x: x[1][0], reverse=True)
            assigned = False
            for shelter_node, (utility, path, route_attrs) in sorted_utilities:
                shelter_idx = self.shelter_mapping[shelter_node]
                if self.shelter_occupancy[shelter_node] < self.shelters.iloc[shelter_idx]['capacity']:
                    self.shelter_occupancy[shelter_node] += 1
                    agent = EvacueeAgent(self, start_node, shelter_node, profile, vulnerability, age, medical_needs, family_status, mobility_level, risk_aversion, water_reserve, preferences, path, route_attrs)
                    self.evacuees.append(agent)
                    self.grid.place_agent(agent, start_node)
                    assigned = True
                    break
            if not assigned:
                logging.warning(f"No available shelter with capacity for agent with profile {profile}")
        self.running = True

    def step(self):
        random.shuffle(self.evacuees)
        for agent in self.evacuees:
            agent.step()
        self.time += 1
        if all(agent.arrived for agent in self.evacuees):
            self.running = False

def main():
    """Main function to run the ABM evacuation route planner."""
    print(f"{Fore.CYAN}=== Nihonbashi Evacuation Route Planner v11 (ABM) ==={Style.RESET_ALL}")
    
    if not test_api_key(GOOGLE_MAPS_API_KEY):
        print(f"{Fore.RED}Please fix your Google Maps API key before proceeding. Exiting.{Style.RESET_ALL}")
        return
    
    try:
        boundary = load_nihonbashi_boundary()
        polygon = boundary.geometry.iloc[0]
    except Exception as e:
        print(f"{Fore.RED}Failed to load boundary: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    try:
        walking_graph = load_walking_graph(polygon)
        max_edge_length = max((data['length'] for u, v, data in walking_graph.edges(data=True)), default=0)
        logging.info(f"Maximum edge length in walking graph: {max_edge_length} meters")
    except Exception as e:
        print(f"{Fore.RED}Failed to load walking graph: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    try:
        shelters = load_evacuation_shelters()
        shelters = shelters[shelters.geometry.within(polygon)]
        if shelters.empty:
            print(f"{Fore.RED}No shelters found within the boundary. Exiting.{Style.RESET_ALL}")
            return
    except Exception as e:
        print(f"{Fore.RED}Failed to load shelters: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    start_address = input("Enter starting address: ")
    start_coords = geocode_address(start_address, GOOGLE_MAPS_API_KEY)
    if start_coords is None:
        print(f"{Fore.RED}Failed to geocode starting address. Exiting.{Style.RESET_ALL}")
        return
    start_lat, start_lon = start_coords
    
    try:
        start_node = ox.distance.nearest_nodes(walking_graph, start_lon, start_lat)
    except Exception as e:
        print(f"{Fore.RED}Failed to find nearest node for start address: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    shelter_nodes = [ox.distance.nearest_nodes(walking_graph, s.geometry.x, s.geometry.y) for s in shelters.itertuples()]
    shelter_mapping = {node: i for i, node in enumerate(shelter_nodes)}
    
    try:
        lengths = nx.single_source_dijkstra_path_length(walking_graph, start_node, weight='length')
        shelter_distances = {shelter_node: lengths[shelter_node] for shelter_node in shelter_nodes if shelter_node in lengths}
        if not shelter_distances:
            print(f"{Fore.RED}No shelters reachable from the starting location. Exiting.{Style.RESET_ALL}")
            return
        top_5_shelters = sorted(shelter_distances.items(), key=lambda x: x[1])[:5]
    except Exception as e:
        print(f"{Fore.RED}Failed to compute shelter distances: {e}. Exiting.{Style.RESET_ALL}")
        return
    
    # Define shelter_nums early
    shelter_nums = {shelter_node: i for i, (shelter_node, _) in enumerate(top_5_shelters, 1)}
    
    print(f"{Fore.CYAN}Closest evacuation shelters:{Style.RESET_ALL}")
    shelter_options = []
    for i, (shelter_node, distance) in enumerate(top_5_shelters, 1):
        shelter_idx = shelter_mapping[shelter_node]
        shelter_info = shelters.iloc[shelter_idx]
        name = shelter_info.get('name', f"Shelter at {shelter_info['latitude']:.4f}, {shelter_info['longitude']:.4f}")
        has_medical_str = " (medical)" if shelter_info['has_medical'] else ""
        family_str = " (family)" if shelter_info['family_friendly'] else ""
        access_str = " (accessible)" if shelter_info['accessible'] else ""
        print(f"{i}. {name}{has_medical_str}{family_str}{access_str} - Capacity: {shelter_info['capacity']} - Distance: {distance:.2f} m")
        shelter_options.append(shelter_node)
    print("Agents will choose shelters based on profiles, preferences, and capacity.")
    
    while True:
        try:
            num_agents = int(input("Enter number of agents to simulate: "))
            if num_agents <= 0:
                raise ValueError("Number of agents must be positive.")
            break
        except ValueError as e:
            print(f"{Fore.RED}Invalid input: {e}. Please enter a positive integer.{Style.RESET_ALL}")
    
    try:
        model = EvacuationModel(num_agents, walking_graph, shelters, start_node, shelter_options)
        with tqdm(total=model.estimated_steps, desc="Simulating evacuation", unit="steps", bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]") as pbar:
            while model.running:
                model.step()
                arrived_count = sum(1 for agent in model.evacuees if agent.arrived)
                pbar.n = min(arrived_count * (model.estimated_steps // num_agents), model.estimated_steps)
                pbar.refresh()
        
        data = []
        for agent in model.evacuees:
            if agent.arrival_time is not None:
                data.append({
                    'profile': agent.profile,
                    'vulnerability': agent.vulnerability,
                    'age': agent.age,
                    'medical_needs': agent.medical_needs,
                    'family_status': agent.family_status,
                    'mobility_level': agent.mobility_level,
                    'risk_aversion': agent.risk_aversion,
                    'water_reserve': agent.water_reserve,
                    'water_needed': agent.water_needed,
                    'preferences': agent.preferences,
                    'arrival_time': agent.arrival_time,
                    'distance': agent.total_distance,
                    'start_node': agent.start_node,
                    'destination_node': agent.destination_node,
                    'path': agent.path,
                    'route_attrs': agent.route_attrs
                })
        
        if not data:
            print(f"{Fore.RED}No agents reached the shelter. Check graph connectivity or shelter location.{Style.RESET_ALL}")
            return
        
        df = pd.DataFrame(data)
        print(f"\n{Fore.GREEN}Simulation completed.{Style.RESET_ALL}")
        print(f"Average arrival time: {df['arrival_time'].mean():.2f} minutes")
        print(f"Total water needed: {df['water_needed'].sum():.2f} liters")
        print(f"Average distance traveled: {df['distance'].mean():.2f} meters")
        
        print(f"\n{Fore.GREEN}Statistics by Profile:{Style.RESET_ALL}")
        stats = df.groupby('profile').agg({
            'arrival_time': ['mean', 'count'],
            'distance': 'mean',
            'water_needed': ['mean', 'sum'],
            'age': 'mean',
            'medical_needs': 'mean',
            'family_status': 'mean',
            'mobility_level': lambda x: x.value_counts().to_dict()
        }).round(2)
        print(stats)
        
        print(f"\n{Fore.GREEN}Shelter Distribution by Profile:{Style.RESET_ALL}")
        shelter_dist = pd.crosstab(df['profile'], df['destination_node'], normalize='index').round(3) * 100
        shelter_dist.columns = [f"Shelter {shelter_nums.get(col, 'Unknown')}" for col in shelter_dist.columns]
        print(shelter_dist)
        
        print("\nShelter Capacity Usage:")
        for node in shelter_options:
            shelter_idx = shelter_mapping[node]
            capacity = shelters.iloc[shelter_idx]['capacity']
            occupancy = model.shelter_occupancy.get(node, 0)
            print(f"Shelter {shelter_nums.get(node, 'Unknown')}: {occupancy}/{capacity} ({occupancy/capacity*100:.1f}%)")
        
        df.to_csv('evacuation_data.csv', index=False)
        print(f"\n{Fore.GREEN}Data saved to 'evacuation_data.csv'.{Style.RESET_ALL}")
        
        nodes = ox.graph_to_gdfs(walking_graph, nodes=True)[0]
        grouped = df.groupby(['profile', 'destination_node'])
        unique_dests = sorted(df['destination_node'].unique())
        
        profile_colors = {
            'Elderly': '#1f77b4',  # Blue
            'Family': '#2ca02c',   # Green
            'Young Adult': '#ff7f0e',  # Orange
            'Mobility Impaired': '#d62728'  # Red
        }
        
        folium_map = folium.Map(location=[nodes.loc[start_node]['y'], nodes.loc[start_node]['x']], zoom_start=15, tiles='openstreetmap')
        
        # Add base graph edges
        base_layer = FeatureGroup(name="Base Map", show=True)
        for u, v, key, data in walking_graph.edges(keys=True, data=True):
            if 'geometry' in data:
                line = data['geometry']
            else:
                line = LineString([(nodes.loc[u, 'x'], nodes.loc[u, 'y']), (nodes.loc[v, 'x'], nodes.loc[v, 'y'])])
            locations = [(y, x) for x, y in line.coords]
            folium.PolyLine(locations, color='gray', weight=1, opacity=0.5).add_to(base_layer)
        base_layer.add_to(folium_map)
        
        folium.GeoJson(boundary, style_function=lambda x: {'color': 'black', 'weight': 2, 'fillOpacity': 0}).add_to(base_layer)
        
        # Add profile-specific layers
        profile_layers = {profile: FeatureGroup(name=f"{profile} Paths", show=False) for profile in AGENT_PROFILES}
        for (profile, dest), group in grouped:
            path = group['path'].iloc[0]
            if len(path) < 2:
                continue
            path_coords = [[nodes.loc[n]['y'], nodes.loc[n]['x']] for n in path if n in nodes.index]
            if path_coords:
                color = profile_colors[profile]
                distance = group['distance'].iloc[0]
                total_agents = len(group)
                avg_arrival = group['arrival_time'].mean()
                total_water = group['water_needed'].sum()
                vuln_stats = group.groupby('vulnerability').agg({
                    'arrival_time': 'mean',
                    'water_needed': 'mean',
                    'vulnerability': 'count'
                }).rename(columns={'vulnerability': 'count'})
                vuln_stats['percentage'] = vuln_stats['count'] / vuln_stats['count'].sum() * 100
                vuln_stats = vuln_stats.round(2)
                stats_table_html = vuln_stats.to_html(border=1)
                route_attrs = group['route_attrs'].iloc[0]
                tooltip_html = f"""
                <b>Path to Shelter {shelter_nums.get(dest, 'Unknown')} (Profile: {profile})</b><br>
                Distance: {distance:.2f} meters<br>
                Total Agents: {total_agents}<br>
                Avg Arrival Time: {avg_arrival:.2f} min<br>
                Total Water Needed: {total_water:.2f} L<br>
                Avg Heat Exposure: {route_attrs['avg_heat_exposure']:.2f}<br>
                Avg Shade: {route_attrs['avg_shade_coverage']:.2f}<br>
                Avg Slope: {route_attrs['avg_slope']:.2f}<br>
                Rest Areas: {route_attrs['total_rest_areas']}<br>
                <br><b>Statistics by Vulnerability:</b><br>
                {stats_table_html}
                """
                folium.PolyLine(path_coords, color=color, weight=3, opacity=0.8, tooltip=tooltip_html).add_to(profile_layers[profile])
        
        for layer in profile_layers.values():
            layer.add_to(folium_map)
        
        folium.Marker(location=[nodes.loc[start_node]['y'], nodes.loc[start_node]['x']],
                     popup='Start Point', icon=folium.Icon(color='red', icon='info-sign')).add_to(base_layer)
        
        for node in unique_dests:
            if node in nodes.index:
                lat = nodes.loc[node]['y']
                lon = nodes.loc[node]['x']
                shelter_idx = shelter_mapping[node]
                capacity = shelters.iloc[shelter_idx]['capacity']
                occupancy = model.shelter_occupancy.get(node, 0)
                popup = f"Shelter {shelter_nums.get(node, 'Unknown')}<br>Occupancy: {occupancy}/{capacity}"
                folium.Marker(location=[lat, lon], popup=popup,
                             icon=folium.Icon(color='blue', icon='info-sign')).add_to(base_layer)
        
        LayerControl().add_to(folium_map)
        folium_map.save('evac_paths_enhanced.html')
        print(f"{Fore.GREEN}Map saved to 'evac_paths_enhanced.html' with profile filters.{Style.RESET_ALL}")
    
    except Exception as e:
        print(f"{Fore.RED}Simulation failed: {e}. Exiting.{Style.RESET_ALL}")
        logging.error(f"Simulation error: {e}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        print(f"{Fore.RED}An error occurred. Check logs for details.{Style.RESET_ALL}")