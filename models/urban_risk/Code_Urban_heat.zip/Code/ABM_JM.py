import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
import random
import matplotlib.pyplot as plt

evac_df = pd.read_csv("C:\evac_control.csv")
evac_gdf = gpd.GeoDataFrame(
    evac_df,
    geometry=gpd.points_from_xy(evac_df.longitude, evac_df.latitude),
    crs="EPSG:4326"
)
shelters = evac_gdf.to_dict("records")

# Step 3: Simulate agents
def generate_agents(n=100):
    agents = []
    for i in range(n):
        lat = 35.678886 + random.uniform(-0.01, 0.01)
        lon = 139.786744 + random.uniform(-0.01, 0.01)
        point = Point(lon, lat)
        heat_scenario = random.choice(["Low", "Moderate", "High"])
        threshold = random.choice(["High", "Moderate"])

        agent = {
            "agent_id": f"A{i+1}",
            "home": point,
            "evac_threshold": threshold,
            "preferred_mode": random.choice(["walk", "drive"]),
            "heat_sensitivity": round(random.uniform(0.4, 1.0), 2),
            "shelter_awareness": random.choice([True, False]),
            "heat_scenario": heat_scenario
        }

        # Predictive Decision
        severity = {"Low": 1, "Moderate": 2, "High": 3}
        agent["evacuate"] = severity[heat_scenario] >= severity[threshold]

        if agent["evacuate"] and agent["shelter_awareness"]:
            chosen = random.choice(shelters)
            agent["shelter_name"] = chosen.get("Name")
        else:
            agent["shelter_name"] = None

        agents.append(agent)
    return pd.DataFrame(agents)

agents_df = generate_agents()

"""

print(agents_df.head())  # first 5 agents
print("\nTotal agents:", len(agents_df))
print("Evacuation rate:", round(agents_df["evacuate"].mean() * 100, 2), "%")

print("\nEvacuation counts by scenario:")
print(agents_df.groupby("heat_scenario")["evacuate"].mean().apply(lambda x: f"{round(x*100, 1)}%"))

print("\nShelter assignment (if any):")
print(agents_df["shelter_name"].value_counts())
"""

agents_df.to_csv(r"C:\ABM\Step3.csv", index=False)



# Step 4: Prescriptive Simulation 
def simulate_upgrade(base_df):
    df = base_df.copy()
    df["heat_sensitivity"] *= 0.85
    df["shelter_awareness"] = True
    df["evac_threshold"] = "Moderate"  # Assume policy lowers barrier

    severity = {"Low": 1, "Moderate": 2, "High": 3}
    df["evacuate"] = df.apply(
        lambda x: severity[x["heat_scenario"]] >= severity[x["evac_threshold"]], axis=1
    )
    df["shelter_name"] = df.apply(
        lambda x: random.choice(shelters)["Name"] if x["evacuate"] else None, axis=1
    )
    return df

# Run both baseline and upgraded simulations
agents_df = generate_agents(100)
agents_upgraded_df = simulate_upgrade(agents_df)


# Comparison between the two simulations
def compare(base, upgraded):
    base_rate = round(base["evacuate"].mean() * 100, 1)
    upgraded_rate = round(upgraded["evacuate"].mean() * 100, 1)
    upgraded_dist = upgraded["shelter_name"].value_counts()

    print("Evacuation Rate (Baseline):", base_rate, "%")
    print("Evacuation Rate (Upgraded):", upgraded_rate, "%")
    print("\nShelter Usage (Upgraded):")
    print(upgraded_dist)

    plt.bar(["Baseline", "Upgraded"], [base_rate, upgraded_rate], color=["gray", "green"])
    plt.ylabel("Evacuation Rate (%)")
    plt.title("Effect of Infrastructure Upgrade on Evacuation")
    plt.ylim(0, 100)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.tight_layout()
    plt.show()

compare(agents_df, agents_upgraded_df)
