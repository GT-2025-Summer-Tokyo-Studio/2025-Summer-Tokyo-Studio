import pandas as pd
import ast
import geopandas as gpd
import osmnx as ox
import folium
from matplotlib import colormaps as cmaps
import matplotlib.colors as mcolors
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import polygonize
import numpy as np

# Load the boundary shapefile
boundary = gpd.read_file("Nihonbashi_Line.shp")
if boundary.crs is None:
    boundary.set_crs(epsg=2451, inplace=True)
boundary = boundary.to_crs(epsg=4326)
geom = boundary.geometry.iloc[0]  # Assuming single geometry

if geom.geom_type == 'Polygon':
    polygon = geom
elif geom.geom_type == 'LineString':
    coords = list(geom.coords)
    if coords[0] != coords[-1]:
        coords.append(coords[0])
    polygon = Polygon(coords)
elif geom.geom_type == 'MultiLineString':
    polys = list(polygonize(geom))
    if polys:
        polygon = polys[0]  # Take the first polygon
    else:
        raise ValueError("Could not polygonize the MultiLineString")
else:
    raise ValueError(f"Unsupported geometry type: {geom.geom_type}")

if not polygon.is_valid:
    polygon = polygon.buffer(0)

# Load the walking graph
walking_graph = ox.graph_from_polygon(polygon, network_type='walk')

# Get nodes and edges GeoDataFrames
nodes, edges = ox.graph_to_gdfs(walking_graph)

# Load the CSV
df = pd.read_csv('evacuation_data.csv')

# Parse the path column
df['path'] = df['path'].apply(ast.literal_eval)

# Group by destination_node
grouped = df.groupby('destination_node')

# Get unique destinations and assign colors using a colormap
unique_dests = sorted(df['destination_node'].unique())
num_dests = len(unique_dests)
cmap = cmaps['tab10']
colors = [cmap(i) for i in np.linspace(0, 1, num_dests)]
dest_color = dict(zip(unique_dests, colors))
shelter_nums = {dest: i+1 for i, dest in enumerate(unique_dests)}

# Get unique paths per destination
unique_paths = df[['destination_node', 'path']].drop_duplicates('destination_node')

# Create the folium map
start_node = df['start_node'].iloc[0]
start_lat = nodes.loc[start_node]['y']
start_lon = nodes.loc[start_node]['x']
folium_map = folium.Map(location=[start_lat, start_lon], zoom_start=15, tiles='openstreetmap')

# Add walking graph edges manually
for u, v, key, data in walking_graph.edges(keys=True, data=True):
    if 'geometry' in data:
        line = data['geometry']
    else:
        line = LineString([(nodes.loc[u, 'x'], nodes.loc[u, 'y']), (nodes.loc[v, 'x'], nodes.loc[v, 'y'])])
    locations = [(y, x) for x, y in line.coords]
    folium.PolyLine(locations, color='gray', weight=1, opacity=0.5).add_to(folium_map)

# Add boundary
folium.GeoJson(boundary, style_function=lambda x: {'color': 'black', 'weight': 2, 'fillOpacity': 0}).add_to(folium_map)

# Add paths with tooltips
for _, row in unique_paths.iterrows():
    path = row['path']
    if len(path) < 2:
        continue
    path_coords = [[nodes.loc[n]['y'], nodes.loc[n]['x']] for n in path if n in nodes.index]  # [lat, lon]
    if path_coords:
        dest = row['destination_node']
        color = dest_color[dest]
        color_hex = mcolors.to_hex(color)
        # Get group data
        group = grouped.get_group(dest)
        sub_df = group[['vulnerability', 'arrival_time', 'distance', 'water_needed']]
        table_html = sub_df.to_html(index=False, border=1)
        tooltip_html = f"<b>Path to Shelter {shelter_nums[dest]}</b><br>{table_html}"
        folium.PolyLine(path_coords, color=color_hex, weight=3, opacity=1, tooltip=tooltip_html).add_to(folium_map)

# Add start point
folium.Marker(location=[start_lat, start_lon], popup='Start Point', icon=folium.Icon(color='red', icon='info-sign')).add_to(folium_map)

# Add shelter points
for dest in unique_dests:
    if dest in nodes.index:
        lat = nodes.loc[dest]['y']
        lon = nodes.loc[dest]['x']
        folium.Marker(location=[lat, lon], popup=f'Shelter {shelter_nums[dest]}', icon=folium.Icon(color='blue', icon='info-sign')).add_to(folium_map)

# Get map HTML
map_html = folium_map._repr_html_()

# Create full HTML with only the map
full_html = f"""
<html>
<head>
<title>Evacuation Map</title>
</head>
<body>
<h1>Evacuation Map</h1>
{map_html}
</body>
</html>
"""

# Save to file
with open('evac_paths_enhanced.html', 'w', encoding='utf-8') as f:
    f.write(full_html)

print("HTML saved to 'evac_paths_enhanced.html'")