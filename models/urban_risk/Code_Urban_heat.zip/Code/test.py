from mesa import Model, Agent

class TestAgent(Agent):
    def __init__(self, unique_id, model, extra_param):
        super().__init__(unique_id, model)
        self.extra_param = extra_param

class TestModel(Model):
    def __init__(self):
        super().__init__()
        agent = TestAgent(1, self, "test")
        print("Agent created successfully")

model = TestModel()